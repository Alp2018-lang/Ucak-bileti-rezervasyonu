
import model.Rezervasyon;
public interface Irezervasyon  {

public void kaydet(Rezervasyon rezerasyon);
public void sil(Rezervasyon rezervasyon);

    
}
