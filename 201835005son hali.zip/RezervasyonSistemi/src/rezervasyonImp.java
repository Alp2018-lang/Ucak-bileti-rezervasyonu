
//Java kütüphanelerini import ettim diye not al 
import db.DB;
import model.Rezervasyon;
import java.util.List;
import model.Rezervasyon;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import java.sql.ResultSet;

public class rezervasyonImp implements Irezervasyon {

    @Override
    public void kaydet(Rezervasyon rezervasyon) {
       
        try {
           //connect adında bellekte yer açtım ardından veritabanını bağladım dersin
            Connection connect = DB.getConnection();
           
        //sql de insert komutuyla "customerinfo" adında table oluşşturdum bu table içinde tc , name, yas ... gibi sütunlar ekledim.
             String sql = "INSERT INTO customerinfo(tc,name,yas,telefon,km) VALUES (?,?,?,?,?)";
            PreparedStatement ps = connect.prepareStatement(sql);
            //sonradan eklendi . 
            ps.setString(1, rezervasyon.getTc());
            ps.setString(2, rezervasyon.getName());
            ps.setString(3, rezervasyon.getYas());
            ps.setString(4, rezervasyon.getTelefon());
            ps.setInt(5, rezervasyon.getKm());
            //executeUpdate komutu ile bkullanıcının girmiş olduğu bilgiler veritabanına kaydediliyor 
            ps.executeUpdate();
            //kaydedilince "SAVED" mesaj penceresi
            JOptionPane.showMessageDialog(null, "SAVED !"); 
        } //hata alınca "ERROR" mesajı ve output da hata kodunun hangi satırda kaynaklandığını gösteriyor
        catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "ERROR !");
            System.out.println("ERROR CODE"+e.getMessage());
        }
        

    }

    @Override
    public void sil(Rezervasyon rezervasyon) {
        throw new UnsupportedOperationException("Not supported yet.");
      
    }

    
        
     
        
    }

        
        
        
    

  

      


    


