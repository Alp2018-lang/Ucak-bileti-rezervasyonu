
package db;

import java.sql.Connection;
import java.sql.DriverManager;



public class DB {
    

    
      static Connection connection;
    static String driver = "com.mysql.jdbc.Driver";
    
    //VERİTABANI BİLGİLERİ  
    static String url = "jdbc:mysql://@localhost:3306/Customers";
    static String username ="root";
    static String password ="123Alp321";
    
    public static Connection getConnection() throws Exception{
        //Veritabanına bağlanmak için
    if(connection == null){
        Class.forName(driver);
        connection =  DriverManager.getConnection(url, username, password);
    }    
        
        
        return connection;
    

    
}
}
