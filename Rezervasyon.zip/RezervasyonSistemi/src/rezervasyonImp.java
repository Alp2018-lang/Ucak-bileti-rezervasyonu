

import db.DB;
import model.Rezervasyon;
import java.util.List;
import model.Rezervasyon;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import java.sql.ResultSet;

public class rezervasyonImp implements Irezervasyon {

    @Override
    public void kaydet(Rezervasyon rezervasyon) {
       
        try {
           
            Connection connect = DB.getConnection();
           
        
             String sql = "INSERT INTO ınformations(tc,name,yas,telefon,km) VALUES (?,?,?,?,?)";
            PreparedStatement ps = connect.prepareStatement(sql);
            //sonradan eklendi . 
            ps.setString(1, rezervasyon.getTc());
            ps.setString(2, rezervasyon.getName());
            ps.setString(3, rezervasyon.getYas());
            ps.setString(4, rezervasyon.getTelefon());
            ps.setInt(5, rezervasyon.getKm());
            
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "SAVED !"); 
        } 
        catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "ERROR !");
            System.out.println("ERROR CODE"+e.getMessage());
        }
        

    }

    @Override
    public void sil(Rezervasyon rezervasyon) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
        
     
        
    }

        
        
        
    

  

      


    


